package examination;

public class Login {
	public final static String ADMIN_USERNAME="admin";
	public final static String ADMIN_PASSWORD="12345678";
	public final static int ADMIN_KEY=123;
	
	
	
}
