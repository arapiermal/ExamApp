module FinalProjectTest {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	
	opens examination to javafx.graphics, javafx.fxml;
}
